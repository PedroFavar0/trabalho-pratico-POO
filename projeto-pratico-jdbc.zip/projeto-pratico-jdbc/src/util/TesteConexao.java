package util;
import java.sql.Connection;
import java.sql.SQLException;

public class TesteConexao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
			Connection conexao = ConnectionFactory.obterConexao();
			System.out.println("Conexão estabelecida");
			System.out.println(conexao.getClass().getName());
			
			conexao.close();
			
		}catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		
	}

}
