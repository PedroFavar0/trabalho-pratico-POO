package util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	public static Connection obterConexao() throws ClassNotFoundException, SQLException {
		
		Class.forName("org.postgresql.Driver");
		
		String url = "jdbc:postgresql://localhost:5432/poo_exercicios";
		String usuario = "postgres";
		String senha = "postgres";
		
		return DriverManager.getConnection(url, usuario, senha);
		
	}
}
