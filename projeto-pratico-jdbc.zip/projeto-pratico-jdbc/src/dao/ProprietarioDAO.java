package dao;

import util.ConnectionFactory;
import model.Proprietario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProprietarioDAO {

	public void salvar(Proprietario proprietario) {

		String sql = "INSERT INTO proprietario (nome_completo, cpf, email) "
				+ "VALUES (?, ?, ?)";

		try (Connection conexao = ConnectionFactory.obterConexao();
				PreparedStatement comando = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);) {

			comando.setString(1, proprietario.getNomeCompleto());
			comando.setString(2, proprietario.getCpf());
			comando.setString(3, proprietario.getEmail());

			comando.executeUpdate();

			try (ResultSet chaves = comando.getGeneratedKeys()) {
				if (chaves.next()) {
					proprietario.setId(chaves.getInt(1));
				}
			}

			System.out.println("Proprietário salvo com sucesso! ID: " + proprietario.getId());

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Erro ao salvar o proprietário: " + e.getMessage());
		}
	}

	public void atualizar(Proprietario proprietario) {

		String sql = "UPDATE proprietario SET nome_completo = ?, cpf = ?, email = ? "
				+ "WHERE id = ?";

		try (Connection conexao = ConnectionFactory.obterConexao();
				PreparedStatement comando = conexao.prepareStatement(sql);) {

			comando.setString(1, proprietario.getNomeCompleto());
			comando.setString(2, proprietario.getCpf());
			comando.setString(3, proprietario.getEmail());
			comando.setInt(4, proprietario.getId());

			comando.executeUpdate();

			System.out.println("Proprietário atualizado com sucesso!");

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Erro ao atualizar o proprietário: " + e.getMessage());
		}
	}

	public void deletar(Integer id) {

		String sql = "DELETE FROM proprietario WHERE id = ?";

		try (Connection conexao = ConnectionFactory.obterConexao();
				PreparedStatement comando = conexao.prepareStatement(sql);) {

			comando.setInt(1, id);

			comando.executeUpdate();

			System.out.println("Proprietário deletado com sucesso!");

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Erro ao deletar o proprietário: " + e.getMessage());
		}
	}

	public List<Proprietario> listarTodos() {
		List<Proprietario> proprietarios = new ArrayList<>();

		String sql = "SELECT id, nome_completo, cpf, email FROM proprietario";

		try (Connection conexao = ConnectionFactory.obterConexao();
				PreparedStatement comando = conexao.prepareStatement(sql);
				ResultSet rs = comando.executeQuery()) {

			while (rs.next()) {
				Proprietario proprietario = new Proprietario(
						rs.getInt("id"),
						rs.getString("nome_completo"),
						rs.getString("cpf"),
						rs.getString("email"));

				proprietarios.add(proprietario);
			}

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Erro ao listar proprietários: " + e.getMessage());
		}

		return proprietarios;
	}

	public Proprietario buscarPorId(Integer id) {
		String sql = "SELECT id, nome_completo, cpf, email FROM proprietario WHERE id = ?";

		try (Connection conexao = ConnectionFactory.obterConexao();
				PreparedStatement comando = conexao.prepareStatement(sql);) {

			comando.setInt(1, id);

			try (ResultSet rs = comando.executeQuery()) {

				if (rs.next()) {
					return new Proprietario(
							rs.getInt("id"),
							rs.getString("nome_completo"),
							rs.getString("cpf"),
							rs.getString("email"));
				}
			}

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Erro ao buscar proprietário: " + e.getMessage());
		}
		return null;
	}
}