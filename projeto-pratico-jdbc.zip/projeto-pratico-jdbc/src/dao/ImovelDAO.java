package dao;

import model.Imovel;
import model.Proprietario;
import util.ConnectionFactory;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class ImovelDAO {

	// Consulta base com JOIN para já montar o Proprietario dentro do Imovel
	private static final String SELECT_BASE =
			"SELECT i.id, i.tipo, i.endereco, i.area_m2, i.valor_aluguel, "
			+ "p.id AS proprietario_id, p.nome_completo, p.cpf, p.email "
			+ "FROM imovel i "
			+ "LEFT JOIN proprietario p ON p.id = i.proprietario_id";

	public void salvar(Imovel imovel) {

		String sql = "INSERT INTO imovel (tipo, endereco, area_m2, valor_aluguel, proprietario_id) "
				+ "VALUES (?, ?, ?, ?, ?)";

		try (Connection conexao = ConnectionFactory.obterConexao();
				PreparedStatement comando = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);) {

			comando.setString(1, imovel.getTipo());
			comando.setString(2, imovel.getEndereco());
			comando.setBigDecimal(3, BigDecimal.valueOf(imovel.getAreaM2()));
			comando.setBigDecimal(4, BigDecimal.valueOf(imovel.getValorAluguel()));

			if (imovel.getProprietario() != null) {
				comando.setInt(5, imovel.getProprietario().getId());
			} else {
				comando.setNull(5, Types.INTEGER);
			}

			comando.executeUpdate();

			try (ResultSet chaves = comando.getGeneratedKeys()) {
				if (chaves.next()) {
					imovel.setId(chaves.getInt(1));
				}
			}

			System.out.println("Imóvel salvo com sucesso! ID: " + imovel.getId());

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Erro ao salvar o imóvel: " + e.getMessage());
		}
	}

	public void atualizar(Imovel imovel) {

		String sql = "UPDATE imovel SET tipo = ?, endereco = ?, area_m2 = ?, "
				+ "valor_aluguel = ?, proprietario_id = ? WHERE id = ?";

		try (Connection conexao = ConnectionFactory.obterConexao();
				PreparedStatement comando = conexao.prepareStatement(sql);) {

			comando.setString(1, imovel.getTipo());
			comando.setString(2, imovel.getEndereco());
			comando.setBigDecimal(3, BigDecimal.valueOf(imovel.getAreaM2()));
			comando.setBigDecimal(4, BigDecimal.valueOf(imovel.getValorAluguel()));

			if (imovel.getProprietario() != null) {
				comando.setInt(5, imovel.getProprietario().getId());
			} else {
				comando.setNull(5, Types.INTEGER);
			}

			comando.setInt(6, imovel.getId());

			comando.executeUpdate();

			System.out.println("Imóvel atualizado com sucesso!");

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Erro ao atualizar o imóvel: " + e.getMessage());
		}
	}

	public void deletar(Integer id) {

		String sql = "DELETE FROM imovel WHERE id = ?";

		try (Connection conexao = ConnectionFactory.obterConexao();
				PreparedStatement comando = conexao.prepareStatement(sql);) {

			comando.setInt(1, id);

			comando.executeUpdate();

			System.out.println("Imóvel deletado com sucesso!");

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Erro ao deletar o imóvel: " + e.getMessage());
		}
	}

	public List<Imovel> listarTodos() {
		List<Imovel> imoveis = new ArrayList<>();

		try (Connection conexao = ConnectionFactory.obterConexao();
				PreparedStatement comando = conexao.prepareStatement(SELECT_BASE);
				ResultSet rs = comando.executeQuery()) {

			while (rs.next()) {
				imoveis.add(mapear(rs));
			}

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Erro ao listar imóveis: " + e.getMessage());
		}

		return imoveis;
	}

	public Imovel buscarPorId(Integer id) {
		String sql = SELECT_BASE + " WHERE i.id = ?";

		try (Connection conexao = ConnectionFactory.obterConexao();
				PreparedStatement comando = conexao.prepareStatement(sql);) {

			comando.setInt(1, id);

			try (ResultSet rs = comando.executeQuery()) {

				if (rs.next()) {
					return mapear(rs);
				}
			}

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Erro ao buscar imóvel: " + e.getMessage());
		}
		return null;
	}

	private Imovel mapear(ResultSet rs) throws SQLException {
		Proprietario proprietario = null;

		int idProprietario = rs.getInt("proprietario_id");
		if (!rs.wasNull()) {
			proprietario = new Proprietario(
					idProprietario,
					rs.getString("nome_completo"),
					rs.getString("cpf"),
					rs.getString("email"));
		}

		return new Imovel(
				rs.getInt("id"),
				rs.getString("tipo"),
				rs.getString("endereco"),
				rs.getDouble("area_m2"),
				rs.getDouble("valor_aluguel"),
				proprietario);
	}
}