package model;

public class Proprietario {
	
	private Integer id;
	private String nomeCompleto;
	private String cpf;
	private String email;
	
	public Proprietario(Integer id, String nomeCompleto, String cpf, String email) {
		super();
		this.id = id;
		this.nomeCompleto = nomeCompleto;
		this.cpf = cpf;
		this.email = email;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNomeCompleto() {
		return nomeCompleto;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
	    return "Proprietario{" +
	            "id=" + id +
	            ", nomeCompleto='" + nomeCompleto + '\'' +
	            ", cpf='" + cpf + '\'' +
	            ", email='" + email + '\'' +
	            '}';
	}

	
}
