package model;

public class Imovel {
	
	private Integer id;
	private String tipo;
	private String endereco;
	private Double areaM2;
	private Double valorAluguel;
	private Proprietario proprietario;
	
	public Imovel(Integer id, String tipo, String endereco, Double areaM2, Double valorAluguel,
			Proprietario proprietario) {
		super();
		this.id = id;
		this.tipo = tipo;
		this.endereco = endereco;
		this.areaM2 = areaM2;
		this.valorAluguel = valorAluguel;
		this.proprietario = proprietario;
	}




	public Integer getId() {
		return id;
	}




	public void setId(Integer id) {
		this.id = id;
	}




	public String getTipo() {
		return tipo;
	}




	public void setTipo(String tipo) {
		this.tipo = tipo;
	}




	public String getEndereco() {
		return endereco;
	}




	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}




	public Double getAreaM2() {
		return areaM2;
	}




	public void setAreaM2(Double areaM2) {
		this.areaM2 = areaM2;
	}




	public Double getValorAluguel() {
		return valorAluguel;
	}




	public void setValorAluguel(Double valorAluguel) {
		this.valorAluguel = valorAluguel;
	}




	public Proprietario getProprietario() {
		return proprietario;
	}




	public void setProprietario(Proprietario proprietario) {
		this.proprietario = proprietario;
	}




	@Override
	public String toString() {
		return "Imovel {" + "id= " + id + "tipo= " + tipo + "endereço= " + endereco + "area em m2= " + areaM2 +
				"valor do aluguel= " + valorAluguel + "Nome do proprietário: " + proprietario.getNomeCompleto();
				
	}
}
