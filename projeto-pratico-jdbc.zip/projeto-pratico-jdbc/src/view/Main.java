package view;

import model.Proprietario;
import model.Imovel;
import dao.ProprietarioDAO;
import dao.ImovelDAO;

public class Main {

	public static void main(String[] args) {

		ProprietarioDAO proprietarioDAO = new ProprietarioDAO();
		ImovelDAO imovelDAO = new ImovelDAO();

		Proprietario p1 = new Proprietario(null, "Carlos Souza", "111.111.111-11", "carlos@email.com");
		Proprietario p2 = new Proprietario(null, "Maria Lima", "222.222.222-22", "maria@email.com");
		Proprietario p3 = new Proprietario(null, "João Alves", "333.333.333-33", "joao@email.com");
		proprietarioDAO.salvar(p1);
		proprietarioDAO.salvar(p2);
		proprietarioDAO.salvar(p3);

		Imovel i1 = new Imovel(null, "Apartamento", "Rua A, 10 - Niterói", 60.0, 2000.00, p1);
		Imovel i2 = new Imovel(null, "Casa", "Rua B, 20 - Rio de Janeiro", 120.0, 3500.00, p2);
		Imovel i3 = new Imovel(null, "Sala Comercial", "Rua C, 30 - Niterói", 40.0, 1800.00, p3);
		imovelDAO.salvar(i1);
		imovelDAO.salvar(i2);
		imovelDAO.salvar(i3);

		p1.setEmail("carlos.novo@email.com");
		proprietarioDAO.atualizar(p1);

		i1.setValorAluguel(2300.00);
		imovelDAO.atualizar(i1);

		imovelDAO.deletar(i3.getId());
		proprietarioDAO.deletar(p3.getId());

		System.out.println("\n--- Proprietários ---");
		for (Proprietario p : proprietarioDAO.listarTodos()) {
			System.out.println(p.getId() + " | " + p.getNomeCompleto() + " | " + p.getEmail());
		}

		System.out.println("\n--- Imóveis ---");
		for (Imovel i : imovelDAO.listarTodos()) {
			System.out.println(i.getId() + " | " + i.getTipo() + " | R$ " + i.getValorAluguel()
					+ " | Proprietário: " + i.getProprietario().getNomeCompleto());
		}
	}
}